import logging
import os
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        self.database_url = os.getenv('DATABASE_URL', '')
        self.engine = None
        self.async_session = None
        self._available = False

    async def init_db(self):
        try:
            from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
            from sqlalchemy.orm import sessionmaker
            from app.models.automation import Base

            self.engine = create_async_engine(self.database_url, echo=False)
            self.async_session = sessionmaker(self.engine, class_=AsyncSession, expire_on_commit=False)
            async with self.engine.begin() as conn:
                await conn.run_sync(Base.metadata.create_all)
            self._available = True
            logger.info("✅ Database initialized")
        except Exception as e:
            logger.warning(f"⚠️ Database not available: {e}")
            self._available = False

    async def create_table_from_schema(self, table_name: str, fields: List[Dict]) -> bool:
        if not self._available:
            logger.info(f"[Mock] Would create table: {table_name}")
            return True
        try:
            import sqlalchemy as sa
            sql = f"CREATE TABLE IF NOT EXISTS {table_name} (\n    id SERIAL PRIMARY KEY,\n"
            for field in fields:
                if field['name'] == 'id':
                    continue
                sql_type = self._map_sql_type(field['type'])
                nullable = "NOT NULL" if field.get('required') else "NULL"
                sql += f"    {field['name']} {sql_type} {nullable},\n"
            sql += "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);"
            async with self.async_session() as session:
                await session.execute(sa.text(sql))
                await session.commit()
            logger.info(f"✅ Table created: {table_name}")
            return True
        except Exception as e:
            logger.error(f"Table creation error: {e}")
            return False

    async def insert_data(self, table_name: str, data: Dict[str, Any]) -> Optional[int]:
        if not self._available:
            return 1
        return None

    async def query_data(self, table_name: str, filters: Dict = None, limit: int = 100) -> List[Dict]:
        return []

    @staticmethod
    def _map_sql_type(field_type: str) -> str:
        return {
            'string': 'VARCHAR(255)', 'integer': 'INTEGER', 'float': 'FLOAT',
            'boolean': 'BOOLEAN', 'date': 'DATE', 'datetime': 'TIMESTAMP',
            'text': 'TEXT', 'array': 'TEXT[]'
        }.get(field_type, 'VARCHAR(255)')

    async def close(self):
        if self.engine:
            await self.engine.dispose()

db_manager = DatabaseManager()

async def init_db():
    await db_manager.init_db()

async def get_session():
    if db_manager.async_session:
        async with db_manager.async_session() as session:
            yield session
