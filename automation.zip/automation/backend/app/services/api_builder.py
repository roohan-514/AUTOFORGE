import json
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class APIBuilder:
    @staticmethod
    def generate_crud_endpoints(entity_name: str, fields: List[Dict]) -> List[Dict]:
        base = f"/api/{entity_name.lower()}"
        return [
            {"endpoint": base, "method": "GET", "description": f"List all {entity_name}", "parameters": ["skip", "limit"]},
            {"endpoint": f"{base}/{{id}}", "method": "GET", "description": f"Get {entity_name} by ID"},
            {"endpoint": base, "method": "POST", "description": f"Create {entity_name}"},
            {"endpoint": f"{base}/{{id}}", "method": "PUT", "description": f"Update {entity_name}"},
            {"endpoint": f"{base}/{{id}}", "method": "DELETE", "description": f"Delete {entity_name}"},
        ]

    @staticmethod
    def generate_api_code(analysis: Dict[str, Any]) -> str:
        apis = analysis.get('apis_to_generate', [])
        entities = analysis.get('entities', [])
        code = "from fastapi import APIRouter, HTTPException\nfrom pydantic import BaseModel\nfrom typing import Optional, List\n\nrouter = APIRouter()\n\n"
        for entity in entities:
            if entity.get('type') == 'table':
                model_name = entity['name'].title()
                code += f"class {model_name}(BaseModel):\n"
                for f in entity.get('fields', []):
                    if f['name'] == 'id':
                        continue
                    py_type = {'string': 'str', 'integer': 'int', 'float': 'float', 'boolean': 'bool'}.get(f['type'], 'str')
                    opt = "" if f.get('required') else " = None"
                    code += f"    {f['name']}: {py_type}{opt}\n"
                code += "\n"
        for api in apis:
            method = api['method'].lower()
            ep = api['endpoint']
            desc = api['description']
            fname = ep.replace('/', '_').replace('{', '').replace('}', '').strip('_') or 'root'
            code += f"@router.{method}(\"{ep}\")\nasync def {method}_{fname}():\n    \"\"\"{desc}\"\"\"\n    return {{\"status\": \"ok\"}}\n\n"
        return code
