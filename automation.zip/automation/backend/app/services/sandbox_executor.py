import subprocess
import asyncio
import tempfile
import os
import time
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

BLOCKED_PATTERNS = [
    'rm -rf', 'sudo', ':(){', 'mkfs', 'dd if=', '> /dev/',
    'shutdown', 'reboot', 'halt', 'format', 'del /f'
]

class SandboxExecutor:
    def __init__(self, timeout: int = 30):
        self.timeout = timeout

    async def execute_python(self, code: str, variables: Dict = None) -> Dict[str, Any]:
        start = time.time()
        try:
            safe_code = self._inject_variables(code, variables or {})
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(safe_code)
                tmp = f.name
            try:
                result = await asyncio.wait_for(
                    self._run(['python3', tmp]),
                    timeout=self.timeout
                )
                elapsed = int((time.time() - start) * 1000)
                return {"status": "success", "output": result, "execution_time_ms": elapsed}
            except asyncio.TimeoutError:
                return {"status": "error", "error": f"Timeout after {self.timeout}s", "code": "TIMEOUT"}
            finally:
                if os.path.exists(tmp):
                    os.remove(tmp)
        except Exception as e:
            return {"status": "error", "error": str(e), "code": "EXECUTION_ERROR"}

    async def execute_javascript(self, code: str) -> Dict[str, Any]:
        start = time.time()
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
                f.write(code)
                tmp = f.name
            try:
                result = await asyncio.wait_for(self._run(['node', tmp]), timeout=self.timeout)
                return {"status": "success", "output": result, "execution_time_ms": int((time.time()-start)*1000)}
            except asyncio.TimeoutError:
                return {"status": "error", "error": f"Timeout after {self.timeout}s", "code": "TIMEOUT"}
            finally:
                if os.path.exists(tmp):
                    os.remove(tmp)
        except Exception as e:
            return {"status": "error", "error": str(e), "code": "EXECUTION_ERROR"}

    async def execute_bash(self, command: str) -> Dict[str, Any]:
        if any(p in command for p in BLOCKED_PATTERNS):
            return {"status": "error", "error": "Blocked command detected", "code": "BLOCKED"}
        try:
            result = await asyncio.wait_for(self._run(['bash', '-c', command]), timeout=self.timeout)
            return {"status": "success", "output": result}
        except asyncio.TimeoutError:
            return {"status": "error", "error": f"Timeout after {self.timeout}s", "code": "TIMEOUT"}
        except Exception as e:
            return {"status": "error", "error": str(e), "code": "EXECUTION_ERROR"}

    async def execute_sql(self, sql: str, database_url: str = None) -> Dict[str, Any]:
        return {
            "status": "success",
            "output": f"SQL validated:\n{sql}\n\n(Connect a database to execute queries)",
            "rows": [],
            "row_count": 0
        }

    async def _run(self, cmd: list) -> str:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0 and stderr:
            return f"[stderr]\n{stderr.decode()}"
        return stdout.decode() if stdout else stderr.decode()

    def _inject_variables(self, code: str, variables: Dict) -> str:
        if not variables:
            return code
        inject = "# Injected variables\n"
        for k, v in variables.items():
            inject += f"{k} = {repr(v)}\n"
        return inject + "\n" + code
