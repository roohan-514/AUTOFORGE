import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

class CodeGenerator:
    @staticmethod
    def generate_python_code(analysis: Dict[str, Any]) -> str:
        entities = analysis.get('entities', [])
        code = "# Auto-Generated Python Code\n# Universal Code Automation Platform\n\n"
        for entity in entities:
            name = entity['name'].title().replace('_', '')
            code += f"class {name}:\n"
            code += f"    \"\"\"Auto-generated model for {entity['name']}\"\"\"\n\n"
            fields = entity.get('fields', [])
            params = ', '.join([f['name'] for f in fields if f['name'] != 'id'])
            code += f"    def __init__(self, {params}):\n"
            for f in fields:
                if f['name'] != 'id':
                    code += f"        self.{f['name']} = {f['name']}\n"
            code += "\n    def to_dict(self):\n        return {\n"
            for f in fields:
                if f['name'] != 'id':
                    code += f"            '{f['name']}': self.{f['name']},\n"
            code += "        }\n\n"
        return code

    @staticmethod
    def generate_sql_code(analysis: Dict[str, Any]) -> str:
        entities = analysis.get('entities', [])
        code = "-- Auto-Generated SQL Schema\n-- Universal Code Automation Platform\n\n"
        for entity in entities:
            if entity['type'] == 'table':
                code += f"CREATE TABLE IF NOT EXISTS {entity['name']} (\n"
                code += "    id SERIAL PRIMARY KEY,\n"
                for field in entity.get('fields', []):
                    if field['name'] == 'id':
                        continue
                    sql_type = CodeGenerator._sql_type(field['type'])
                    nullable = "NOT NULL" if field.get('required') else "NULL"
                    code += f"    {field['name']} {sql_type} {nullable},\n"
                code += "    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\n"
        return code

    @staticmethod
    def _sql_type(field_type: str) -> str:
        return {
            'string': 'VARCHAR(255)',
            'integer': 'INTEGER',
            'float': 'FLOAT',
            'boolean': 'BOOLEAN',
            'date': 'DATE',
            'datetime': 'TIMESTAMP',
            'text': 'TEXT',
            'array': 'TEXT[]'
        }.get(field_type, 'VARCHAR(255)')

    @staticmethod
    def generate_fastapi_code(analysis: Dict[str, Any]) -> str:
        entities = analysis.get('entities', [])
        apis = analysis.get('apis_to_generate', [])
        code = "# Auto-Generated FastAPI Code\nfrom fastapi import APIRouter, HTTPException\nfrom pydantic import BaseModel\nfrom typing import Optional, List\nfrom datetime import datetime\n\nrouter = APIRouter()\n\n"
        for entity in entities:
            model_name = entity['name'].title().replace('_', '')
            code += f"class {model_name}(BaseModel):\n"
            for f in entity.get('fields', []):
                if f['name'] == 'id':
                    continue
                py_type = {'string': 'str', 'integer': 'int', 'float': 'float', 'boolean': 'bool', 'datetime': 'Optional[str]'}.get(f['type'], 'str')
                optional = "" if f.get('required') else " = None"
                code += f"    {f['name']}: {py_type}{optional}\n"
            code += "\n"
        for api in apis:
            method = api['method'].lower()
            endpoint = api['endpoint']
            desc = api['description']
            func_name = endpoint.replace('/', '_').replace('{', '').replace('}', '').strip('_') or 'root'
            code += f"@router.{method}(\"{endpoint}\", summary=\"{desc}\")\nasync def {method}_{func_name}():\n    \"\"\"{ desc }\"\"\"\n    return {{\"message\": \"Endpoint ready\", \"status\": \"ok\"}}\n\n"
        return code
