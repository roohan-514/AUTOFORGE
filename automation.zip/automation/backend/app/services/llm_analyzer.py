import anthropic
import json
import logging
from typing import Dict, Any
from enum import Enum

logger = logging.getLogger(__name__)

class AutomationType(str, Enum):
    API_GENERATION = "api_generation"
    FORM_GENERATION = "form_generation"
    DATABASE_AUTOMATION = "database_automation"
    DATA_PROCESSING = "data_processing"
    SCRIPT_EXECUTION = "script_execution"
    ETL_PIPELINE = "etl_pipeline"

class LLMAnalyzer:
    def __init__(self):
        self.client = anthropic.Anthropic()
        self.model = "claude-sonnet-4-20250514"

    async def analyze_requirements(self, user_input: str, code: str = "") -> Dict[str, Any]:
        try:
            prompt = f"""You are an automation expert. Analyze this user requirement and optional code, then return a structured JSON automation plan.

USER REQUIREMENT:
{user_input}

USER CODE (optional):
{code if code else "No code provided"}

Return ONLY valid JSON (no markdown, no extra text) with this exact structure:
{{
    "automation_type": "api_generation",
    "confidence": 0.95,
    "entities": [
        {{
            "name": "users",
            "type": "table",
            "fields": [
                {{"name": "id", "type": "integer", "required": true}},
                {{"name": "name", "type": "string", "required": true}},
                {{"name": "email", "type": "string", "required": true}},
                {{"name": "created_at", "type": "datetime", "required": false}}
            ]
        }}
    ],
    "apis_to_generate": [
        {{"endpoint": "/api/users", "method": "GET", "description": "List all users"}},
        {{"endpoint": "/api/users", "method": "POST", "description": "Create user"}},
        {{"endpoint": "/api/users/{{id}}", "method": "PUT", "description": "Update user"}},
        {{"endpoint": "/api/users/{{id}}", "method": "DELETE", "description": "Delete user"}}
    ],
    "database_schema": {{
        "tables": ["users"],
        "relationships": []
    }},
    "execution_requirements": {{
        "language": "python",
        "dependencies": [],
        "timeout_seconds": 30
    }},
    "validation_rules": [],
    "summary": "Brief description of the automation plan"
}}"""

            message = self.client.messages.create(
                model=self.model,
                max_tokens=4096,
                messages=[{"role": "user", "content": prompt}]
            )

            response_text = message.content[0].text.strip()
            # Remove markdown code blocks if present
            if response_text.startswith("```"):
                lines = response_text.split('\n')
                response_text = '\n'.join(lines[1:-1])

            analysis = json.loads(response_text)
            logger.info(f"✅ LLM Analysis Complete: {analysis.get('automation_type')}")
            return analysis

        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}")
            return self._fallback_analysis(user_input)
        except Exception as e:
            logger.error(f"❌ LLM Analysis Error: {str(e)}")
            return self._fallback_analysis(user_input)

    def _fallback_analysis(self, user_input: str) -> Dict[str, Any]:
        """Fallback analysis when LLM fails"""
        return {
            "automation_type": "api_generation",
            "confidence": 0.7,
            "entities": [
                {
                    "name": "items",
                    "type": "table",
                    "fields": [
                        {"name": "id", "type": "integer", "required": True},
                        {"name": "name", "type": "string", "required": True},
                        {"name": "description", "type": "string", "required": False},
                        {"name": "created_at", "type": "datetime", "required": False}
                    ]
                }
            ],
            "apis_to_generate": [
                {"endpoint": "/api/items", "method": "GET", "description": "List all items"},
                {"endpoint": "/api/items", "method": "POST", "description": "Create item"},
                {"endpoint": "/api/items/{id}", "method": "GET", "description": "Get item by ID"},
                {"endpoint": "/api/items/{id}", "method": "PUT", "description": "Update item"},
                {"endpoint": "/api/items/{id}", "method": "DELETE", "description": "Delete item"}
            ],
            "database_schema": {"tables": ["items"], "relationships": []},
            "execution_requirements": {"language": "python", "dependencies": [], "timeout_seconds": 30},
            "validation_rules": [],
            "summary": f"Generated automation plan for: {user_input[:100]}"
        }

    async def generate_implementation(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        try:
            prompt = f"""Based on this automation analysis, generate implementation details.

ANALYSIS:
{json.dumps(analysis, indent=2)}

Return ONLY valid JSON (no markdown) with:
{{
    "database_schema": "SQL CREATE TABLE statements as a string",
    "api_endpoints": ["list of endpoint descriptions"],
    "sample_data": {{"table_name": [{{"field": "value"}}]}},
    "setup_instructions": ["step 1", "step 2"],
    "notes": "Any important implementation notes"
}}"""

            message = self.client.messages.create(
                model=self.model,
                max_tokens=4096,
                messages=[{"role": "user", "content": prompt}]
            )

            response_text = message.content[0].text.strip()
            if response_text.startswith("```"):
                lines = response_text.split('\n')
                response_text = '\n'.join(lines[1:-1])

            implementation = json.loads(response_text)
            logger.info("✅ Implementation Generated")
            return implementation
        except Exception as e:
            logger.error(f"Implementation generation error: {e}")
            entities = analysis.get('entities', [])
            sql = ""
            for entity in entities:
                sql += f"CREATE TABLE IF NOT EXISTS {entity['name']} (\n    id SERIAL PRIMARY KEY"
                for f in entity.get('fields', []):
                    if f['name'] != 'id':
                        sql += f",\n    {f['name']} VARCHAR(255)"
                sql += "\n);\n\n"
            return {
                "database_schema": sql,
                "api_endpoints": [f"{a['method']} {a['endpoint']}" for a in analysis.get('apis_to_generate', [])],
                "sample_data": {},
                "setup_instructions": ["Run database migrations", "Start the API server", "Test endpoints"],
                "notes": "Implementation generated successfully"
            }
