import re

class Validators:
    @staticmethod
    def validate_email(email: str) -> bool:
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))

    @staticmethod
    def validate_code(code: str, language: str) -> bool:
        return bool(code and code.strip())

    @staticmethod
    def validate_requirement(requirement: str) -> bool:
        return bool(requirement and len(requirement.strip()) >= 10)
