from fastapi import FastAPI, WebSocket, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging
import os
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 Starting Universal Code Automation Platform")
    try:
        from app.services.database_manager import init_db
        await init_db()
        logger.info("✅ Database initialized")
    except Exception as e:
        logger.warning(f"⚠️ Database initialization skipped: {e}")
    yield
    logger.info("🛑 Shutting down application")

app = FastAPI(
    title="Universal Code Automation Platform",
    description="Automate code generation, API creation, and database management with AI",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from app.routes import automation, execution, health
app.include_router(health.router, prefix="/api/v1", tags=["Health"])
app.include_router(automation.router, prefix="/api/v1", tags=["Automation"])
app.include_router(execution.router, prefix="/api/v1", tags=["Execution"])

@app.get("/")
async def root():
    return {
        "message": "Universal Code Automation Platform",
        "version": "1.0.0",
        "docs": "/docs",
        "status": "operational"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
