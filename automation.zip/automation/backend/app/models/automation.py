from sqlalchemy import Column, Integer, String, Text, DateTime
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class AutomationRecord(Base):
    __tablename__ = "automations"
    id = Column(Integer, primary_key=True, index=True)
    automation_id = Column(String(255), unique=True, index=True)
    status = Column(String(50))
    requirement = Column(Text)
    code = Column(Text, nullable=True)
    language = Column(String(50))
    analysis = Column(Text)
    implementation = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ExecutionRecord(Base):
    __tablename__ = "executions"
    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String(255), unique=True, index=True)
    automation_id = Column(String(255), nullable=True)
    language = Column(String(50))
    code = Column(Text)
    status = Column(String(50))
    output = Column(Text, nullable=True)
    error = Column(Text, nullable=True)
    execution_time_ms = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
