from datetime import datetime
from enum import Enum

class ExecutionStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"

class ExecutionResult:
    def __init__(self, execution_id: str, status: str, output: str = None, error: str = None):
        self.execution_id = execution_id
        self.status = status
        self.output = output
        self.error = error
        self.timestamp = datetime.utcnow()
