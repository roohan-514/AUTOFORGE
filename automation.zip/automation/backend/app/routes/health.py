from fastapi import APIRouter
from datetime import datetime

router = APIRouter()

@router.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "Universal Code Automation Platform",
        "version": "1.0.0"
    }

@router.get("/ready")
async def ready_check():
    return {
        "ready": True,
        "components": {
            "llm": "initialized",
            "executor": "ready",
            "api_builder": "ready"
        }
    }
