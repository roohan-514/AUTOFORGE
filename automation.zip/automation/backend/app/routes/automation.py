from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import uuid
import logging
from datetime import datetime

logger = logging.getLogger(__name__)
router = APIRouter()

# In-memory store (replace with DB in production)
automations_store: Dict[str, Any] = {}

class AutomationRequest(BaseModel):
    requirement: str
    code: Optional[str] = None
    language: Optional[str] = "python"

class AutomationResponse(BaseModel):
    automation_id: str
    status: str
    analysis: Dict[str, Any]
    generated_apis: List[Dict]
    estimated_setup_time: str

@router.post("/automation/analyze", response_model=AutomationResponse)
async def analyze_automation(request: AutomationRequest):
    """Analyze user requirements with AI and generate automation plan"""
    try:
        automation_id = str(uuid.uuid4())

        from app.services.llm_analyzer import LLMAnalyzer
        from app.services.api_builder import APIBuilder

        analyzer = LLMAnalyzer()
        analysis = await analyzer.analyze_requirements(request.requirement, request.code or "")

        entities = analysis.get('entities', [])
        apis = []
        for entity in entities:
            if entity.get('type') == 'table':
                apis.extend(APIBuilder.generate_crud_endpoints(entity['name'], entity.get('fields', [])))

        if not apis:
            apis = analysis.get('apis_to_generate', [])

        automations_store[automation_id] = {
            "status": "analyzed",
            "timestamp": datetime.now().isoformat(),
            "analysis": analysis,
            "apis": apis,
            "request": request.dict()
        }

        logger.info(f"✅ Automation analyzed: {automation_id}")
        return AutomationResponse(
            automation_id=automation_id,
            status="analyzed",
            analysis=analysis,
            generated_apis=apis,
            estimated_setup_time="2-5 minutes"
        )
    except Exception as e:
        logger.error(f"Analysis error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/automation/generate")
async def generate_automation(automation_id: str):
    """Generate and deploy full automation based on analysis"""
    try:
        if automation_id not in automations_store:
            raise HTTPException(status_code=404, detail="Automation not found")

        automation = automations_store[automation_id]
        analysis = automation['analysis']

        from app.services.llm_analyzer import LLMAnalyzer
        from app.services.code_generator import CodeGenerator
        from app.services.database_manager import db_manager

        analyzer = LLMAnalyzer()
        implementation = await analyzer.generate_implementation(analysis)

        # Generate code artifacts
        python_code = CodeGenerator.generate_python_code(analysis)
        sql_code = CodeGenerator.generate_sql_code(analysis)
        fastapi_code = CodeGenerator.generate_fastapi_code(analysis)

        # Create tables if DB available
        tables_created = 0
        for entity in analysis.get('entities', []):
            if entity.get('type') == 'table':
                success = await db_manager.create_table_from_schema(entity['name'], entity.get('fields', []))
                if success:
                    tables_created += 1

        automation['status'] = 'generated'
        automation['implementation'] = implementation
        automation['generated_code'] = {
            "python": python_code,
            "sql": sql_code,
            "fastapi": fastapi_code
        }

        logger.info(f"✅ Automation generated: {automation_id}")
        return {
            "automation_id": automation_id,
            "status": "generated",
            "tables_created": tables_created,
            "apis_ready": len(automation['apis']),
            "implementation": implementation,
            "generated_code": automation['generated_code'],
            "next_steps": [
                "Test APIs using the execution console",
                "Review generated SQL schema",
                "Deploy to production with Docker"
            ]
        }
    except Exception as e:
        logger.error(f"Generation error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/automation/{automation_id}")
async def get_automation(automation_id: str):
    if automation_id not in automations_store:
        raise HTTPException(status_code=404, detail="Automation not found")
    automation = automations_store[automation_id]
    return {
        "automation_id": automation_id,
        "status": automation['status'],
        "timestamp": automation['timestamp'],
        "analysis": automation['analysis'],
        "apis": automation['apis'],
        "implementation": automation.get('implementation', {}),
        "generated_code": automation.get('generated_code', {})
    }

@router.get("/automation")
async def list_automations():
    return {
        "total": len(automations_store),
        "automations": [
            {"id": aid, "status": data['status'], "timestamp": data['timestamp'],
             "summary": data['analysis'].get('summary', '')[:80]}
            for aid, data in automations_store.items()
        ]
    }
