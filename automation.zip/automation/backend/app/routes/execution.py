from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
import logging
import uuid
from datetime import datetime

logger = logging.getLogger(__name__)
router = APIRouter()

execution_store: Dict[str, Any] = {}

class ExecutionRequest(BaseModel):
    code: str
    language: str = "python"
    variables: Optional[Dict[str, Any]] = None
    timeout: Optional[int] = 30

class ExecutionResponse(BaseModel):
    execution_id: str
    status: str
    output: Optional[str] = None
    error: Optional[str] = None
    execution_time_ms: float

@router.post("/execute", response_model=ExecutionResponse)
async def execute_code(request: ExecutionRequest):
    """Execute code securely in a sandboxed environment"""
    try:
        execution_id = str(uuid.uuid4())
        from app.services.sandbox_executor import SandboxExecutor
        executor = SandboxExecutor(timeout=request.timeout or 30)

        if request.language == "python":
            result = await executor.execute_python(request.code, request.variables)
        elif request.language == "javascript":
            result = await executor.execute_javascript(request.code)
        elif request.language == "sql":
            result = await executor.execute_sql(request.code)
        elif request.language == "bash":
            result = await executor.execute_bash(request.code)
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported language: {request.language}")

        execution_store[execution_id] = {
            "timestamp": datetime.now().isoformat(),
            "language": request.language,
            "result": result
        }

        logger.info(f"✅ Code executed: {execution_id} - Status: {result['status']}")
        return ExecutionResponse(
            execution_id=execution_id,
            status=result['status'],
            output=result.get('output', ''),
            error=result.get('error'),
            execution_time_ms=result.get('execution_time_ms', 0)
        )
    except Exception as e:
        logger.error(f"Execution error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/execute/{execution_id}")
async def get_execution(execution_id: str):
    if execution_id not in execution_store:
        raise HTTPException(status_code=404, detail="Execution not found")
    return {"execution_id": execution_id, **execution_store[execution_id]}

@router.get("/executions")
async def list_executions():
    return {
        "total": len(execution_store),
        "executions": [
            {"id": eid, "language": data['language'], "status": data['result']['status'], "timestamp": data['timestamp']}
            for eid, data in execution_store.items()
        ]
    }
