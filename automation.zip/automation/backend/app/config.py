import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql+asyncpg://automation_user:automation_password@localhost:5432/automation_db")
    ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
    DEBUG: bool = os.getenv("DEBUG", "True") == "True"
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", 8000))
    EXECUTOR_TIMEOUT: int = int(os.getenv("EXECUTOR_TIMEOUT", 30))
    EXECUTOR_MEMORY_LIMIT: str = os.getenv("EXECUTOR_MEMORY_LIMIT", "512m")

settings = Settings()
