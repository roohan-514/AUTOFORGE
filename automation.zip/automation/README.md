# ⚡ AutoForge — Universal Code Automation Platform

> Transform any requirement into fully automated solutions with AI-powered code generation, secure execution, and automatic API creation.

![AutoForge](https://img.shields.io/badge/AutoForge-v1.0-6c63ff?style=for-the-badge)
![Claude AI](https://img.shields.io/badge/Powered%20by-Claude%20AI-ff6584?style=for-the-badge)
![FastAPI](https://img.shields.io/badge/Backend-FastAPI-43e97b?style=for-the-badge)
![React](https://img.shields.io/badge/Frontend-React-38bdf8?style=for-the-badge)

---

## ✨ Features

- **🤖 AI-Powered Analysis** — Claude AI understands any requirement and creates a full automation plan
- **🗄️ Auto Database Schema** — Tables and schemas created automatically from your description
- **📡 Auto API Generation** — Full REST CRUD APIs generated instantly
- **🔒 Secure Code Execution** — Run Python, JavaScript, SQL, Bash in sandboxed environments
- **📋 Form & Table Automation** — Auto-fills forms and tables from database
- **⚡ Real-time Results** — Live execution feedback with history

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose installed
- Anthropic API Key ([get one here](https://console.anthropic.com))

### 1. Clone & Setup

```bash
git clone https://github.com/roohan-514/automation.git
cd automation
cp .env.example .env
```

### 2. Add your API Key

Edit `.env`:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### 3. Start everything

```bash
docker-compose up -d
```

### 4. Open the platform

| Service | URL |
|---------|-----|
| 🌐 Frontend | http://localhost:3000 |
| 📄 API Docs | http://localhost:8000/docs |
| 🗄️ Database | localhost:5432 |

---

## 🛠️ Manual Setup (without Docker)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env       # add your ANTHROPIC_API_KEY
uvicorn app.main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
# Opens at http://localhost:3000
```

---

## 📖 How to Use

1. **Describe** — Write what you want to automate in plain English
2. **Analyze** — Claude AI creates a structured plan with entities, APIs, schema
3. **Generate** — All code, tables, and APIs are created automatically
4. **Execute** — Test your code in the secure sandbox console

### Example Input

```
Create a user management system with name, email, phone, address fields.
Support user roles (admin, user, guest). Generate CRUD APIs, auto-fill
the users table from the database, and validate email and phone formats.
```

### What Gets Generated

- ✅ SQL `CREATE TABLE` statements
- ✅ Python Pydantic models
- ✅ FastAPI router with all endpoints
- ✅ Database table (if PostgreSQL connected)
- ✅ Full REST API reference

---

## 🏗️ Architecture

```
┌─────────────────────────────────┐
│     React Frontend (:3000)      │
│  InputStep → Analysis → Execute │
└──────────────┬──────────────────┘
               │ REST API
┌──────────────▼──────────────────┐
│    FastAPI Backend (:8000)      │
│  ├─ /api/v1/automation/analyze  │
│  ├─ /api/v1/automation/generate │
│  ├─ /api/v1/execute             │
│  └─ /api/v1/health              │
│                                 │
│  Services:                      │
│  ├─ LLM Analyzer (Claude AI)    │
│  ├─ Sandbox Executor            │
│  ├─ API Builder                 │
│  ├─ Code Generator              │
│  └─ Database Manager            │
└──────────────┬──────────────────┘
               │
┌──────────────▼──────────────────┐
│    PostgreSQL Database (:5432)  │
└─────────────────────────────────┘
```

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/automation/analyze` | Analyze requirements with AI |
| `POST` | `/api/v1/automation/generate` | Generate full automation |
| `GET`  | `/api/v1/automation/{id}` | Get automation details |
| `GET`  | `/api/v1/automation` | List all automations |
| `POST` | `/api/v1/execute` | Execute code in sandbox |
| `GET`  | `/api/v1/execute/{id}` | Get execution result |
| `GET`  | `/api/v1/health` | Health check |

Full interactive docs at: **http://localhost:8000/docs**

---

## 🔒 Security

- ✅ Sandboxed code execution with subprocess isolation
- ✅ Timeout protection (30s default)
- ✅ Blocked dangerous commands (`rm -rf`, `sudo`, etc.)
- ✅ Input validation with Pydantic
- ✅ CORS protection

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

## 🙌 Credits

Built with [Claude AI](https://anthropic.com) · [FastAPI](https://fastapi.tiangolo.com) · [React](https://react.dev) · [PostgreSQL](https://postgresql.org)
