import React, { useState, useCallback } from 'react'
import Header from './components/Header'
import InputStep from './components/InputStep'
import AnalysisStep from './components/AnalysisStep'
import GeneratedStep from './components/GeneratedStep'
import ExecutionStep from './components/ExecutionStep'
import StepIndicator from './components/StepIndicator'
import './styles/App.css'

const STEPS = ['input', 'analysis', 'generated', 'execution']

export default function App() {
  const [step, setStep] = useState('input')
  const [automationId, setAutomationId] = useState(null)
  const [automationData, setAutomationData] = useState(null)
  const [generatedData, setGeneratedData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleAnalyze = useCallback(async (requirement, code, language) => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/v1/automation/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requirement, code, language })
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.detail || 'Analysis failed')
      }
      const data = await res.json()
      setAutomationId(data.automation_id)
      setAutomationData(data)
      setStep('analysis')
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  const handleGenerate = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/v1/automation/generate?automation_id=${automationId}`, {
        method: 'POST'
      })
      if (!res.ok) {
        const err = await res.json()
        throw new Error(err.detail || 'Generation failed')
      }
      const data = await res.json()
      setGeneratedData(data)
      setStep('generated')
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [automationId])

  const handleReset = () => {
    setStep('input')
    setAutomationId(null)
    setAutomationData(null)
    setGeneratedData(null)
    setError(null)
  }

  return (
    <div className="app">
      <div className="app-bg">
        <div className="bg-grid" />
        <div className="bg-glow bg-glow-1" />
        <div className="bg-glow bg-glow-2" />
        <div className="bg-glow bg-glow-3" />
      </div>

      <Header onReset={handleReset} currentStep={step} />

      <main className="app-main">
        <StepIndicator currentStep={step} steps={STEPS} />

        {error && (
          <div className="error-banner fade-up">
            <span className="error-icon">⚠</span>
            <span>{error}</span>
            <button onClick={() => setError(null)} className="error-close">×</button>
          </div>
        )}

        <div className="step-container">
          {step === 'input' && (
            <InputStep onAnalyze={handleAnalyze} loading={loading} />
          )}
          {step === 'analysis' && automationData && (
            <AnalysisStep
              data={automationData}
              onGenerate={handleGenerate}
              onBack={() => setStep('input')}
              loading={loading}
            />
          )}
          {step === 'generated' && generatedData && (
            <GeneratedStep
              data={generatedData}
              automationData={automationData}
              onExecute={() => setStep('execution')}
              onReset={handleReset}
            />
          )}
          {step === 'execution' && (
            <ExecutionStep
              automationId={automationId}
              onBack={() => setStep('generated')}
              onReset={handleReset}
            />
          )}
        </div>
      </main>

      <footer className="app-footer">
        <span>AutoForge v1.0 — Powered by Claude AI</span>
        <span className="footer-dot">◆</span>
        <span>Universal Code Automation Platform</span>
      </footer>
    </div>
  )
}
