import React from 'react'

export default function AnalysisStep({ data, onGenerate, onBack, loading }) {
  const { analysis, generated_apis = [], estimated_setup_time } = data
  const entities = analysis?.entities || []
  const tables = entities.filter(e => e.type === 'table')
  const confidence = Math.round((analysis?.confidence || 0.9) * 100)

  return (
    <div className="analysis-step fade-up">
      {/* Header */}
      <div className="analysis-header">
        <div>
          <p style={{ fontSize: '0.72rem', color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '0.25rem' }}>
            Analysis Complete
          </p>
          <h2 className="analysis-title">Your Automation Plan</h2>
        </div>
        <div className="analysis-badge">
          <span>●</span>
          {confidence}% Confidence
        </div>
      </div>

      {/* Summary */}
      <div className="summary-box">
        <strong style={{ color: 'var(--accent)', fontFamily: 'var(--font-head)' }}>AI Summary: </strong>
        {analysis?.summary || 'Automation plan generated successfully.'}
      </div>

      {/* Stats */}
      <div className="analysis-grid">
        <div className="stat-card">
          <div className="stat-value">{tables.length}</div>
          <div className="stat-label">Database Tables</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{generated_apis.length}</div>
          <div className="stat-label">API Endpoints</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{entities.reduce((a, e) => a + (e.fields?.length || 0), 0)}</div>
          <div className="stat-label">Total Fields</div>
        </div>
      </div>

      {/* Entities + APIs */}
      <div className="analysis-cols">
        {/* Entities */}
        <div className="card">
          <p className="section-title">Detected Entities</p>
          <h3 className="card-title" style={{ fontSize: '0.95rem', marginBottom: '1rem' }}>Database Schema</h3>
          {entities.length === 0 ? (
            <p style={{ color: 'var(--text3)', fontSize: '0.82rem' }}>No entities detected.</p>
          ) : (
            entities.map((entity, i) => (
              <div key={i} className="entity-card">
                <div className="entity-name">
                  📋 {entity.name}
                  <span className="entity-type-badge">{entity.type}</span>
                </div>
                <div className="field-list">
                  {(entity.fields || []).map((f, j) => (
                    <span key={j} className={`field-tag ${f.required ? 'required' : ''}`}>
                      {f.name}
                      <span style={{ opacity: 0.5, marginLeft: '3px', fontSize: '0.6rem' }}>{f.type}</span>
                    </span>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* APIs */}
        <div className="card">
          <p className="section-title">Generated Endpoints</p>
          <h3 className="card-title" style={{ fontSize: '0.95rem', marginBottom: '1rem' }}>REST APIs</h3>
          {generated_apis.length === 0 ? (
            <p style={{ color: 'var(--text3)', fontSize: '0.82rem' }}>No APIs generated.</p>
          ) : (
            generated_apis.map((api, i) => (
              <div key={i} className="api-row">
                <span className={`method-badge method-${api.method}`}>{api.method}</span>
                <span className="api-endpoint">{api.endpoint}</span>
                <span className="api-desc">{api.description}</span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Automation type + execution info */}
      <div className="card" style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap' }}>
        <div>
          <p className="section-title">Automation Type</p>
          <p style={{ color: 'var(--accent4)', fontWeight: '700', marginTop: '0.25rem' }}>
            {analysis?.automation_type?.replace(/_/g, ' ').toUpperCase() || 'API GENERATION'}
          </p>
        </div>
        <div>
          <p className="section-title">Language</p>
          <p style={{ color: 'var(--accent3)', fontWeight: '700', marginTop: '0.25rem' }}>
            {analysis?.execution_requirements?.language?.toUpperCase() || 'PYTHON'}
          </p>
        </div>
        <div>
          <p className="section-title">Est. Setup Time</p>
          <p style={{ color: 'var(--text)', marginTop: '0.25rem' }}>{estimated_setup_time}</p>
        </div>
        {analysis?.execution_requirements?.dependencies?.length > 0 && (
          <div>
            <p className="section-title">Dependencies</p>
            <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', marginTop: '0.25rem' }}>
              {analysis.execution_requirements.dependencies.map((d, i) => (
                <span key={i} style={{ fontSize: '0.72rem', background: 'var(--bg2)', border: '1px solid var(--border)', padding: '2px 8px', borderRadius: '4px', color: 'var(--text2)' }}>{d}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="action-bar">
        <button onClick={onBack} className="btn-secondary" disabled={loading}>
          ← Back
        </button>
        <button onClick={onGenerate} disabled={loading} className="btn-primary btn-success">
          {loading ? (
            <><span className="spinner" style={{ borderTopColor: '#0a0a0f' }} />Generating...</>
          ) : (
            <>⚡ Generate & Deploy All</>
          )}
        </button>
        <p style={{ fontSize: '0.75rem', color: 'var(--text3)', marginLeft: '0.5rem' }}>
          This will create tables, APIs, and generate all code
        </p>
      </div>
    </div>
  )
}
