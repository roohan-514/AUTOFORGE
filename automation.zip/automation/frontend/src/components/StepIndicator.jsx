import React from 'react'

const LABELS = {
  input: 'Input',
  analysis: 'Analysis',
  generated: 'Generate',
  execution: 'Execute'
}

export default function StepIndicator({ currentStep, steps }) {
  const currentIdx = steps.indexOf(currentStep)

  return (
    <div className="step-indicator">
      {steps.map((s, i) => {
        const isDone = i < currentIdx
        const isActive = i === currentIdx
        return (
          <React.Fragment key={s}>
            <div className={`step-item ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}`}>
              <div className={`step-num ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}`}>
                {isDone ? '✓' : i + 1}
              </div>
              <span className="step-label">{LABELS[s]}</span>
            </div>
            {i < steps.length - 1 && (
              <div className={`step-connector ${isDone ? 'done' : ''}`} />
            )}
          </React.Fragment>
        )
      })}
    </div>
  )
}
