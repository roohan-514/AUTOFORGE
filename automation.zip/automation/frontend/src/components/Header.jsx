import React from 'react'
import '../styles/App.css'

export default function Header({ onReset, currentStep }) {
  return (
    <header className="app-header">
      <div className="header-logo" onClick={onReset} title="Reset to start">
        <div className="logo-icon">⚡</div>
        <span className="logo-text">AutoForge</span>
        <span className="logo-tag">v1.0</span>
      </div>

      <nav className="header-nav">
        <a
          href="http://localhost:8000/docs"
          target="_blank"
          rel="noopener noreferrer"
          className="nav-link"
        >
          API Docs ↗
        </a>
        <a
          href="https://console.anthropic.com"
          target="_blank"
          rel="noopener noreferrer"
          className="nav-link"
        >
          Get API Key ↗
        </a>
        {currentStep !== 'input' && (
          <button onClick={onReset} className="btn-reset">
            ↺ New Project
          </button>
        )}
        <div className="status-dot">
          <div className="dot-live" />
          LIVE
        </div>
      </nav>
    </header>
  )
}
