import React, { useState } from 'react'

const EXAMPLES = [
  {
    icon: '👤',
    label: 'User Management System',
    text: 'Create a complete user management system with name, email, phone, address fields. Support user roles (admin, user, guest). Generate CRUD APIs, auto-fill tables from database, and validate email/phone formats.'
  },
  {
    icon: '🛒',
    label: 'E-Commerce Product Catalog',
    text: 'Build a product catalog with products, categories, inventory tracking. Include price, stock quantity, SKU, description. Auto-generate search APIs, filter by category, track low-stock alerts.'
  },
  {
    icon: '📊',
    label: 'Sales Analytics Dashboard',
    text: 'Create a sales tracking system with orders, customers, products. Track revenue, generate monthly reports, auto-fill sales tables from transactions database.'
  },
  {
    icon: '📋',
    label: 'Task Management App',
    text: 'Build a task management system with projects, tasks, users, comments. Support priority levels, due dates, status tracking. Generate REST APIs and auto-fill task board from database.'
  },
  {
    icon: '🏥',
    label: 'Patient Records System',
    text: 'Create a medical records system with patient info, appointments, diagnoses, prescriptions. Ensure HIPAA-compliant field structure, generate audit APIs, auto-fill patient history.'
  }
]

export default function InputStep({ onAnalyze, loading }) {
  const [requirement, setRequirement] = useState('')
  const [code, setCode] = useState('')
  const [language, setLanguage] = useState('python')

  const handleSubmit = () => {
    if (requirement.trim().length < 10) {
      alert('Please describe your requirement in at least 10 characters.')
      return
    }
    onAnalyze(requirement, code, language)
  }

  const handleExample = (ex) => {
    setRequirement(ex.text)
  }

  const charCount = requirement.length

  return (
    <div className="input-step fade-up">
      {/* Left column - main input */}
      <div className="input-left">
        <div className="card">
          <p className="section-title">Step 1 — Describe</p>
          <h2 className="card-title">What do you want to automate?</h2>
          <p className="card-subtitle">
            Describe your requirements in plain English. Include fields, relationships, APIs needed, and any existing code.
          </p>

          <div style={{ marginBottom: '1rem' }}>
            <label className="field-label">Requirement / Description *</label>
            <textarea
              value={requirement}
              onChange={e => setRequirement(e.target.value)}
              rows={8}
              placeholder="E.g. Create a user management system with name, email, phone fields. Auto-fill the users table from database, generate CRUD APIs, validate email format..."
              disabled={loading}
            />
            <div style={{ textAlign: 'right', fontSize: '0.7rem', color: charCount > 20 ? 'var(--accent3)' : 'var(--text3)', marginTop: '0.25rem' }}>
              {charCount} chars
            </div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <label className="field-label">Language</label>
            <select value={language} onChange={e => setLanguage(e.target.value)} disabled={loading}>
              <option value="python">Python</option>
              <option value="javascript">JavaScript / Node.js</option>
              <option value="sql">SQL</option>
              <option value="bash">Bash / Shell</option>
            </select>
          </div>

          <div style={{ marginBottom: '1.5rem' }}>
            <label className="field-label">Existing Code (optional)</label>
            <textarea
              value={code}
              onChange={e => setCode(e.target.value)}
              rows={6}
              className="code-textarea"
              placeholder="# Paste any existing code here (optional)&#10;# The AI will incorporate it into the automation plan&#10;&#10;def validate_email(email):&#10;    import re&#10;    return bool(re.match(r'[^@]+@[^@]+\.[^@]+', email))"
              disabled={loading}
            />
          </div>

          <button
            onClick={handleSubmit}
            disabled={loading || requirement.trim().length < 10}
            className="btn-primary"
            style={{ width: '100%', justifyContent: 'center' }}
          >
            {loading ? (
              <>
                <span className="spinner" />
                Analyzing with Claude AI...
              </>
            ) : (
              <>
                ⚡ Analyze & Generate Plan
              </>
            )}
          </button>
        </div>
      </div>

      {/* Right column - examples + tips */}
      <div className="input-right">
        <div className="card">
          <p className="section-title">Quick Start</p>
          <h3 className="card-title" style={{ fontSize: '0.95rem' }}>Try an Example</h3>
          <p className="card-subtitle">Click any example to pre-fill the form.</p>
          <div className="examples-list">
            {EXAMPLES.map((ex, i) => (
              <button key={i} className="example-chip" onClick={() => handleExample(ex)} disabled={loading}>
                <span className="chip-icon">{ex.icon}</span>
                <span className="chip-text">{ex.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <p className="section-title">How it works</p>
          <ul className="tips-list">
            <li><span className="tip-icon">→</span> Claude AI reads your requirement and generates a full automation plan</li>
            <li><span className="tip-icon">→</span> Database schema and tables are created automatically</li>
            <li><span className="tip-icon">→</span> REST APIs are generated with full CRUD operations</li>
            <li><span className="tip-icon">→</span> Code is executed securely in a sandboxed environment</li>
            <li><span className="tip-icon">→</span> Everything is production-ready and downloadable</li>
          </ul>
        </div>

        <div className="card" style={{ background: 'linear-gradient(135deg, rgba(108,99,255,0.1), rgba(240,147,251,0.05))', borderColor: 'rgba(108,99,255,0.3)' }}>
          <p className="section-title">Powered by</p>
          <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', marginTop: '0.5rem' }}>
            {['Claude AI', 'FastAPI', 'PostgreSQL', 'Docker', 'React'].map(t => (
              <span key={t} style={{ fontSize: '0.72rem', background: 'var(--surface)', border: '1px solid var(--border)', padding: '3px 10px', borderRadius: '20px', color: 'var(--text2)' }}>{t}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
