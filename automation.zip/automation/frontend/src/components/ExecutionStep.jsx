import React, { useState, useRef } from 'react'

const EXAMPLES = {
  python: `# Test automation logic
import json
from datetime import datetime

data = {
    "user": "AutoForge",
    "timestamp": datetime.now().isoformat(),
    "status": "running",
    "tasks": ["schema created", "apis generated", "tests passed"]
}

print("✅ Automation Test Result:")
print(json.dumps(data, indent=2))
print(f"\\n🕐 Executed at: {datetime.now().strftime('%H:%M:%S')}")`,

  javascript: `// Test automation in JavaScript
const data = {
  platform: "AutoForge",
  timestamp: new Date().toISOString(),
  apis: ["GET /api/users", "POST /api/users", "PUT /api/users/:id", "DELETE /api/users/:id"],
  status: "operational"
};

console.log("⚡ Automation Test:");
console.log(JSON.stringify(data, null, 2));
console.log("\\n✅ All systems operational!");`,

  sql: `-- Test SQL automation
SELECT 
  'AutoForge' AS platform,
  NOW() AS timestamp,
  'Schema Ready' AS status,
  5 AS tables_created,
  20 AS apis_generated;`,

  bash: `echo "🚀 AutoForge Automation Check"
echo "================================"
echo "Platform: Universal Code Automation"
echo "Status: Running"
echo "Time: $(date)"
echo "================================"
echo "✅ Sandbox execution working!"`
}

export default function ExecutionStep({ automationId, onBack, onReset }) {
  const [code, setCode] = useState(EXAMPLES.python)
  const [language, setLanguage] = useState('python')
  const [output, setOutput] = useState(null)
  const [status, setStatus] = useState('idle')
  const [execTime, setExecTime] = useState(null)
  const [history, setHistory] = useState([])
  const outputRef = useRef(null)

  const handleLanguageChange = (lang) => {
    setLanguage(lang)
    setCode(EXAMPLES[lang] || '')
  }

  const handleExecute = async () => {
    if (!code.trim()) return
    setStatus('running')
    setOutput(null)
    const start = Date.now()

    try {
      const res = await fetch('/api/v1/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language, timeout: 30 })
      })
      const data = await res.json()
      const elapsed = Date.now() - start
      setExecTime(elapsed)
      setStatus(data.status)
      setOutput(data.output || data.error || 'No output')
      setHistory(prev => [{
        id: data.execution_id,
        language,
        status: data.status,
        time: new Date().toLocaleTimeString(),
        ms: elapsed
      }, ...prev.slice(0, 9)])
    } catch (e) {
      setStatus('error')
      setOutput(`Network error: ${e.message}`)
    }
  }

  return (
    <div className="execution-step fade-up">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
        <div>
          <p style={{ fontSize: '0.72rem', color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Step 4</p>
          <h2 style={{ fontFamily: 'var(--font-head)', fontSize: '1.5rem', fontWeight: 800 }}>Execution Console</h2>
        </div>
        <div style={{ display: 'flex', gap: '0.75rem' }}>
          {status !== 'idle' && (
            <div className={`exec-status ${status}`}>
              {status === 'running' ? '⏳' : status === 'success' ? '✓' : '✗'} {status.toUpperCase()}
              {execTime && status !== 'running' && ` (${execTime}ms)`}
            </div>
          )}
        </div>
      </div>

      <div className="execution-grid">
        {/* Editor */}
        <div className="card" style={{ padding: '1.25rem' }}>
          <div className="exec-toolbar">
            <p className="section-title" style={{ margin: 0 }}>Code Editor</p>
            <select
              value={language}
              onChange={e => handleLanguageChange(e.target.value)}
              className="lang-select-small"
              style={{ width: 'auto', marginLeft: 'auto' }}
            >
              <option value="python">Python</option>
              <option value="javascript">JavaScript</option>
              <option value="sql">SQL</option>
              <option value="bash">Bash</option>
            </select>
          </div>
          <textarea
            value={code}
            onChange={e => setCode(e.target.value)}
            rows={16}
            className="code-textarea"
            style={{ marginBottom: '1rem', minHeight: '320px' }}
            placeholder="Write your code here..."
          />
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button onClick={handleExecute} disabled={status === 'running' || !code.trim()} className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}>
              {status === 'running' ? <><span className="spinner" />Executing...</> : <>▶ Run Code</>}
            </button>
            <button onClick={() => { setCode(''); setOutput(null); setStatus('idle') }} className="btn-secondary">
              Clear
            </button>
          </div>
        </div>

        {/* Output */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div className="card" style={{ flex: 1, padding: '1.25rem' }}>
            <p className="section-title">Output</p>
            <div
              ref={outputRef}
              className={`output-panel ${status === 'success' ? 'output-success' : status === 'error' ? 'output-error' : 'output-waiting'}`}
              style={{ minHeight: '280px' }}
            >
              {output === null ? (
                <span className="output-waiting">{'>'} Waiting for execution...\n\nPress "Run Code" to execute your code in the sandbox.</span>
              ) : output}
            </div>
          </div>

          {/* History */}
          <div className="card" style={{ padding: '1.25rem' }}>
            <p className="section-title" style={{ marginBottom: '0.75rem' }}>Execution History</p>
            {history.length === 0 ? (
              <p style={{ fontSize: '0.78rem', color: 'var(--text3)' }}>No executions yet</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                {history.map((h, i) => (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.75rem', color: 'var(--text3)' }}>
                    <span style={{ color: h.status === 'success' ? 'var(--accent3)' : 'var(--accent2)' }}>
                      {h.status === 'success' ? '✓' : '✗'}
                    </span>
                    <span style={{ color: 'var(--text2)', fontFamily: 'var(--font-mono)' }}>{h.language}</span>
                    <span>{h.time}</span>
                    <span style={{ marginLeft: 'auto' }}>{h.ms}ms</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick snippets */}
      <div className="card">
        <p className="section-title" style={{ marginBottom: '0.75rem' }}>Quick Snippets</p>
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          {Object.entries(EXAMPLES).map(([lang, snippet]) => (
            <button
              key={lang}
              className="example-chip"
              style={{ padding: '0.4rem 0.9rem' }}
              onClick={() => { setLanguage(lang); setCode(snippet); setOutput(null); setStatus('idle') }}
            >
              <span className="chip-text">{lang === 'python' ? '🐍' : lang === 'javascript' ? '🟨' : lang === 'sql' ? '🗄️' : '🖥️'} {lang}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="action-bar">
        <button onClick={onBack} className="btn-secondary">← Back to Results</button>
        <button onClick={onReset} className="btn-secondary">↺ New Project</button>
        <a href="http://localhost:8000/docs" target="_blank" rel="noopener noreferrer" className="btn-primary" style={{ textDecoration: 'none' }}>
          📄 View API Docs ↗
        </a>
      </div>
    </div>
  )
}
