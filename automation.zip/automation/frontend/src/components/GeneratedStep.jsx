import React, { useState } from 'react'

export default function GeneratedStep({ data, automationData, onExecute, onReset }) {
  const [activeTab, setActiveTab] = useState('sql')

  const code = data?.generated_code || {}
  const impl = data?.implementation || {}
  const apis = automationData?.generated_apis || []

  const tabs = [
    { key: 'sql', label: '📄 SQL Schema' },
    { key: 'python', label: '🐍 Python Models' },
    { key: 'fastapi', label: '⚡ FastAPI Routes' },
  ]

  const codeContent = {
    sql: code.sql || impl.database_schema || '-- No SQL generated',
    python: code.python || '# No Python code generated',
    fastapi: code.fastapi || '# No FastAPI code generated',
  }

  const steps = impl.setup_instructions || [
    'Add your ANTHROPIC_API_KEY to .env',
    'Run: docker-compose up -d',
    'Backend API: http://localhost:8000/docs',
    'Frontend: http://localhost:3000',
    'Test your endpoints in the Execution Console'
  ]

  return (
    <div className="generated-step fade-up">
      {/* Success Header */}
      <div className="generated-header">
        <span className="success-icon">🎉</span>
        <h2 className="generated-title">Automation Generated!</h2>
        <p className="generated-subtitle">
          {data?.tables_created || 0} tables created · {data?.apis_ready || apis.length} APIs ready · All code generated
        </p>
      </div>

      {/* Metrics */}
      <div className="generated-grid">
        <div className="metric-card">
          <div className="metric-icon">🗄️</div>
          <div className="metric-value">{data?.tables_created ?? '—'}</div>
          <div className="metric-label">Tables Created</div>
        </div>
        <div className="metric-card">
          <div className="metric-icon">📡</div>
          <div className="metric-value">{data?.apis_ready ?? apis.length}</div>
          <div className="metric-label">APIs Ready</div>
        </div>
        <div className="metric-card">
          <div className="metric-icon">📦</div>
          <div className="metric-value">{Object.keys(codeContent).length}</div>
          <div className="metric-label">Code Files</div>
        </div>
      </div>

      {/* Generated code viewer */}
      <div className="card">
        <p className="section-title">Generated Code</p>
        <h3 className="card-title" style={{ fontSize: '0.95rem', marginBottom: '1rem' }}>Review & Copy</h3>
        <div className="code-tabs">
          <div className="tab-bar">
            {tabs.map(t => (
              <button
                key={t.key}
                className={`tab-btn ${activeTab === t.key ? 'active' : ''}`}
                onClick={() => setActiveTab(t.key)}
              >
                {t.label}
              </button>
            ))}
            <button
              className="tab-btn"
              style={{ marginLeft: 'auto' }}
              onClick={() => {
                navigator.clipboard.writeText(codeContent[activeTab])
                  .then(() => alert('Copied to clipboard!'))
                  .catch(() => {})
              }}
            >
              📋 Copy
            </button>
          </div>
          <div className="code-block">{codeContent[activeTab]}</div>
        </div>
      </div>

      {/* Setup Steps */}
      <div className="card">
        <p className="section-title">Deployment</p>
        <h3 className="card-title" style={{ fontSize: '0.95rem', marginBottom: '1rem' }}>Next Steps</h3>
        <div className="steps-list">
          {steps.map((s, i) => (
            <div key={i} className="step-row">
              <div className="step-row-num">{i + 1}</div>
              <span>{s}</span>
            </div>
          ))}
        </div>
        {impl.notes && (
          <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'var(--bg2)', borderRadius: 'var(--radius)', fontSize: '0.82rem', color: 'var(--text2)', borderLeft: '3px solid var(--accent)' }}>
            <strong style={{ color: 'var(--accent)' }}>Note: </strong>{impl.notes}
          </div>
        )}
      </div>

      {/* API List */}
      {apis.length > 0 && (
        <div className="card">
          <p className="section-title">Ready Endpoints</p>
          <h3 className="card-title" style={{ fontSize: '0.95rem', marginBottom: '1rem' }}>API Reference</h3>
          {apis.map((api, i) => (
            <div key={i} className="api-row">
              <span className={`method-badge method-${api.method}`}>{api.method}</span>
              <span className="api-endpoint">{api.endpoint}</span>
              <span className="api-desc">{api.description}</span>
            </div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="action-bar">
        <button onClick={onReset} className="btn-secondary">
          ↺ New Project
        </button>
        <button onClick={onExecute} className="btn-primary">
          ▶ Open Execution Console →
        </button>
      </div>
    </div>
  )
}
